var searchData=
[
  ['generaterandomorientation_50',['generateRandomOrientation',['../game_8c.html#a676d727fded66c75168008cf29a5adf6',1,'generateRandomOrientation():&#160;game.c'],['../game_8h.html#a676d727fded66c75168008cf29a5adf6',1,'generateRandomOrientation():&#160;game.c']]]
];
