var searchData=
[
  ['row_67',['row',['../structBoat.html#a17da210c751576b6ecbf285c58ae01ad',1,'Boat']]]
];
