var searchData=
[
  ['performshot_53',['performShot',['../game_8c.html#a37a876ac85981698e5bd94d766eb58ea',1,'performShot(struct GameBoard *board, int row, int col, bool isPlayer):&#160;game.c'],['../game_8h.html#a37a876ac85981698e5bd94d766eb58ea',1,'performShot(struct GameBoard *board, int row, int col, bool isPlayer):&#160;game.c']]],
  ['placeboat_54',['placeBoat',['../game_8c.html#a7a1922d865c13a150d8dadf20681fba5',1,'placeBoat(struct GameBoard *board, struct Boat *boat):&#160;game.c'],['../game_8h.html#a7a1922d865c13a150d8dadf20681fba5',1,'placeBoat(struct GameBoard *board, struct Boat *boat):&#160;game.c']]],
  ['placerandomboats_55',['placeRandomBoats',['../game_8c.html#ac2b5a2e72d25138369c928786e82c5c2',1,'placeRandomBoats(struct GameBoard *board, struct Boat *boats, int *boatSizes, unsigned int seed):&#160;game.c'],['../game_8h.html#ac2b5a2e72d25138369c928786e82c5c2',1,'placeRandomBoats(struct GameBoard *board, struct Boat *boats, int *boatSizes, unsigned int seed):&#160;game.c']]],
  ['playerturn_56',['playerTurn',['../game_8c.html#a3ea8aa2cb81e250fb85813a0b57bc13f',1,'playerTurn(struct Game *game):&#160;game.c'],['../game_8h.html#a3ea8aa2cb81e250fb85813a0b57bc13f',1,'playerTurn(struct Game *game):&#160;game.c']]],
  ['playgame_57',['playGame',['../game_8c.html#a4cbfdb17bf51e00546880626f7e80429',1,'playGame():&#160;game.c'],['../game_8h.html#a4cbfdb17bf51e00546880626f7e80429',1,'playGame():&#160;game.c']]]
];
