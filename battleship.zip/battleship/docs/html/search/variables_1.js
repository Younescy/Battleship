var searchData=
[
  ['col_60',['col',['../structBoat.html#a22a87ce4fe0d2fb3919b10283feae0c8',1,'Boat']]],
  ['computerboard_61',['computerBoard',['../structGame.html#afc84a97740fd88cdd05e65036092dfe3',1,'Game']]],
  ['computerboats_62',['computerBoats',['../structGame.html#ad5c9c3e62aee5cd470114bb3bb0e7d05',1,'Game']]]
];
