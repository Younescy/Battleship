var searchData=
[
  ['size_33',['size',['../structBoat.html#ab02b26ac6f3061d322320bc5c5f3810d',1,'Boat::size()'],['../structGameBoard.html#aff54e7150e8b4130cefe056b7a22f47b',1,'GameBoard::size()']]]
];
