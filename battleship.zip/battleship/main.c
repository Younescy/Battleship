#include "game.h"

int main() {
    playGame();
    return 0;
}
