# Battleship
## Battleship Game in C


## To generate Documentation : doxygen Doxyfile in terminal, and open index.html (or any other html file if index is not generated, depending if you are on Ubuntu or Debian)generated in repertory docs/

## To compile the code : make all

## To execute/play the game : ./battleship nt

## To remove outputs and executable : make clean


ENJOY !
